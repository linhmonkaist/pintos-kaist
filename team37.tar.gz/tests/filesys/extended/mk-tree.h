#ifndef TESTS_FILESYS_EXTENDED_MK_TREE_H
#define TESTS_FILESYS_EXTENDED_MK_TREE_H

void make_tree (int at, int bt, int ct, int dt);

#endif /* tests/filesys/extended/mk-tree.h */
