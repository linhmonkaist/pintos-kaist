#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include <stdint.h>
#include "threads/thread.h"

void syscall_init (void);

#endif /* userprog/syscall.h */
